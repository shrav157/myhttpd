#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <pthread.h>
#include<time.h>


#define PORT 8080
#define BACKLOG 10
#define DOCUMENT_ROOT "./www"

const char *html_content = 
"<!DOCTYPE html>\n"
"<html lang=\"en\">\n"
"<head>\n"
"    <meta charset=\"UTF-8\">\n"
"    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n"
"    <title>Indian Space Research Organisation (ISRO)</title>\n"
"    <style>\n"
"        body {\n"
"            font-family: Arial, sans-serif;\n"
"            margin: 20px;\n"
"            padding: 0;\n"
"        }\n"
"        header {\n"
"            background-color: #FF9933;\n"
"            color: #FFFFFF;\n"
"            text-align: center;\n"
"            padding: 10px;\n"
"        }\n"
"        main {\n"
"            margin-top: 20px;\n"
"            padding: 20px;\n"
"            border: 1px solid #DDD;\n"
"            background-color: #F7F7F7;\n"
"        }\n"
"        h1 {\n"
"            color: #333;\n"
"        }\n"
"        h2 {\n"
"            color: #555;\n"
"        }\n"
"        p {\n"
"            line-height: 1.5;\n"
"        }\n"
"        img {\n"
"            max-width: 100%;\n"
"            margin-bottom: 15px;\n"
"        }\n"
"    </style>\n"
"</head>\n"
"<body>\n"
"    <header>\n"
"        <h1>Indian Space Research Organisation (ISRO)</h1>\n"
"    </header>\n"
"    <main>\n"
"        <h2>Empowering India's Space Ambitions</h2>\n"
"        <p>The Indian Space Research Organisation (ISRO) is the space agency of the Government of India, responsible for the nation's space research and exploration endeavors.</p>\n"
"        <!-- ... (Rest of the content) ... -->\n"
"        <img src=\"isro_logo.jpg\" alt=\"ISRO Logo\">\n"
"        <img src=\"mars_orbiter_mission.jpg\" alt=\"Mars Orbiter Mission\">\n"
"    </main>\n"
"</body>\n"
"</html>";


    
    void log_request(const char *client_ip, const char *request_line, int status, int response_size) {
    time_t now;
    time(&now);
    char timestamp[128];
    strftime(timestamp, sizeof(timestamp), "[%d/%b/%Y:%H:%M:%S %z]", localtime(&now));
    
    printf("%s %s %s \"%s\" %d %d\n", client_ip, timestamp, timestamp, request_line, status, response_size);
    // You can also write this log to a file instead of printing to stdout
}

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;


void *handle_connection(void *arg) {
    int client_socket = *((int *)arg);
    char buffer[1024] = {0};
    char response[1024] = {0};

    // Read the request from the client
    ssize_t bytes_read = read(client_socket, buffer, sizeof(buffer));
    if (bytes_read == -1) {
        perror("Error reading from client socket");
        close(client_socket);
        return NULL;
  }
    // Process the request and generate the response
    time_t now;
    time(&now);
    char date_buffer[128];
    strftime(date_buffer, sizeof(date_buffer), "%a, %d %b %Y %H:%M:%S GMT", gmtime(&now));


    sprintf(response,
            "HTTP/1.0 200 OK\r\n"
            "Date: %s\r\n"
            "Server: MyHTTPD/1.0\r\n"
            "Last-Modified: %s\r\n"
            "Content-Type: text/html\r\n"
            "Content-Length: %d\r\n\r\n"
            "%s",date_buffer, date_buffer, (int)strlen(html_content),html_content);
            
            pthread_mutex_lock(&mutex);

            
    // Send the response to the client
    ssize_t bytes_sent = write(client_socket, response, strlen(response));
    if (bytes_sent == -1) {
        perror("Error writing to client socket");
    }
    
    // Log the request information
    log_request("127.0.0.1", "GET /index.html HTTP/1.0", 200, (int)strlen(html_content));


    // Unlock the mutex after accessing shared resources
    pthread_mutex_unlock(&mutex);

    // Close the client socket
    close(client_socket);

    return NULL;
}



int main() {
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len = sizeof(client_addr);
    pthread_t tid;
    
if (pthread_mutex_init(&mutex, NULL) != 0) {
        perror("Mutex initialization failed");
        exit(EXIT_FAILURE);
    }
    

    // Create socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket == -1) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Initialize server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // Bind
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1) {
        perror("Bind failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    // Listen
    if (listen(server_socket, BACKLOG) == -1) {
        perror("Listen failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    printf("Server is listening on port %d...\n", PORT);

    // Accept and handle incoming connections
    while (1) {
        client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &client_len);
        if (client_socket == -1) {
            perror("Accept failed");
            continue;
        }

        // Create a new thread to handle the connection
        if (pthread_create(&tid, NULL, handle_connection, &client_socket) != 0) {
            perror("Thread creation failed");
            close(client_socket);
            continue;
        }

        // Detach the thread to allow it to run independently
        if (pthread_detach(tid) != 0) {
            perror("Thread detachment failed");
            close(client_socket);
            continue;
        }
    }

    // Close the server socket
    close(server_socket);

 pthread_mutex_destroy(&mutex);

    return 0;
}
