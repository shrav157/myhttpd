# Multi-threaded Web Server (myhttpd)

MyHTTPD is a multi-threaded web server implemented in C/C++ on a UNIX-based platform. It serves HTTP/1.0 requests, responding to GET and HEAD requests according to RFC1945.
This is a simple multi-threaded web server implementation in C/C++ for a UNIX-based platform.

## Table of Contents

- [Introduction](#introduction)
- [Prerequisites](#Prerequistes)
- [Compilation](#compilation)
- [Running the Server](#running-the-server)
- [Options](#options)
- [Logging](#logging)
- [Multithreading](#multithreading)
- [Synchronization](#synchronization)
- [Project Structure](#project-structure)
- [References](#references)
- [Contact Information](#contact-information)

## IntroductionMulti-threaded Web Server (myhttpd)
Welcome to the README for the `myhttpd` project, a multi-threaded web server implemented in C/C++. This server is designed to run on a UNIX-based platform, serving HTTP/1.0 GET and HEAD requests, handling multiple connections concurrently, and providing basic logging and queuing mechanisms.
This document provides instructions on how to compile and run the server, explains the available options, describes the logging format, outlines the multithreading approach, and covers synchronization techniques used to ensure thread safety.
Please follow the instructions below to get started with the `myhttpd` web server and explore its features.

## Prerequisites
- UNIX-based platform
- C/C++ compiler (GCC recommended)
- POSIX threads library (pthread)

## Compilation
1. Open a terminal and navigate to the directory containing the source code.
2. Type `make` to compile the server.
3. If compilation is successful, the "myhttpd" binary will be created in the same directory.

#Running the Server

./myhttpd [-d] [-h] [-l file] [-p port] [-r dir] [-t time] [-n threadnum] [-s sched]

# Options

- `-d`: Enter debugging mode. Run the server in the foreground, accept one connection at a time, and log to stdout.
- `-h`: Print a usage summary with all options and exit.
- `-l file`: Log all requests to the given file.
- `-p port`: Listen on the specified port (default: 8080).
- `-r dir`: Set the root directory for the server to `dir`.
- `-t time`: Set the queuing time to `time` seconds (default: 60 seconds).
- `-n threadnum`: Set the number of threads waiting ready in the execution thread pool to `threadnum` (default: 4 execution threads).
- `-s sched`: Set the scheduling policy. It can be either FCFS or SJF (default: FCFS).

- **Response Format:**
  When a connection is made, `myhttpd` responds with the appropriate HTTP/1.0 status code and the following headers:
  - **Date:** The current timestamp in GMT.
  - **Server:** A string identifying this server and its version.
  - **Last-Modified:** The timestamp in GMT of the requested file's last modification date.
  - **Content-Type:** Set to `text/html` or `image/gif` depending on the content type.
  - **Content-Length:** Indicates the size in bytes of the data returned.

- **GET Request:**
  If the request type is GET, `myhttpd` returns the data of the requested file. After serving the request, the connection is terminated.

- **HEAD Request:**
  For HEAD requests, only metadata is returned, and no actual content is included in the response.

- **Directory Request:**
  If the request was for a directory and the directory does not contain an "index.html" file, `myhttpd` generates a directory index. The index lists the contents of the directory in alphanumeric order. Files starting with a "." are ignored.

- **User Directory (~) Mapping:**
  If a request begins with a tilde `~`, the subsequent string up to the first slash is translated into the user's `myhttpd` directory. For example, if the request is `~/documents/index.html`, it is translated to `/home/<username>/myhttpd/documents/index.html`.

This protocol implementation ensures that `myhttpd` responds to various types of requests and provides appropriate content, metadata, and directory listing responses.

## Logging

By default, `myhttpd` does not perform any logging. However, you can enable logging to capture information about incoming requests. When logging is explicitly enabled using the `-l` flag, `myhttpd` will log every request in a format similar to Apache's "common" log format.

### Log Format

The log format consists of the following fields, each separated by a space:

- **%a:** The remote IP address from which the request originated.
- **%t:** The time when the request was received by the queuing thread (in GMT).
- **%t:** The time when the request was assigned to an execution thread by the scheduler (in GMT).
- **%r:** The (quoted) first line of the request.
- **%>s:** The status of the request (HTTP status code).
- **%b:** The size of the response in bytes (i.e., "Content-Length").

### Example Log Entry

Here's an example of a log entry:

127.0.0.1 - [19/Sep/2011:13:55:36 -0600] [19/Sep/2011:13:58:21 -0600] "GET /index.html HTTP/1.0" 200 326

# Multithreading and Synchronization

The `myhttpd` server leverages multithreading to efficiently handle multiple incoming connections concurrently. It consists of a queuing thread and an execution thread pool for serving requests.
- **Queuing Thread:** This thread continuously listens for incoming HTTP requests and inserts them into a ready queue.
- **Execution Thread Pool:** A pool of execution threads is always ready to handle requests from the queue. These threads are responsible for processing and serving requests.
The server uses synchronization mechanisms to ensure thread safety and prevent race conditions when accessing shared resources such as the ready queue. Proper synchronization ensures that multiple threads can access and modify shared data structures without conflicts.
For a deeper understanding of how synchronization is achieved in the `myhttpd` server, refer to the synchronization section in the assignment guidelines. Techniques such as mutexes and other synchronization primitives are employed to manage access to critical sections of the code.
Through effective multithreading and synchronization, the `myhttpd` server can efficiently manage and serve multiple requests concurrently.


# Project Structure
1.src/: Contains the source code files (.c).
2.include/: Contains the header files (.h).
3.Makefile: Automates the compilation process.
4.index.html: it contains all html codes
5.README.md: This file with instructions and project details.

# References
RFC1945 - HTTP/1.0 Specification
POSIX Threads Programming
~chatgpt
~bibliography

# Contact Information
For questions or feedback, please contact:
[SHRAVYA kOTIAN]
[shravya1573@gmail.com]
